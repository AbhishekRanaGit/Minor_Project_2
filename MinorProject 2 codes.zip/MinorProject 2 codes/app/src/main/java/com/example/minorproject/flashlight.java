package com.example.minorproject;

import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class flashlight extends AppCompatActivity {
    Switch aSwitch;
    TextView textView;
    CameraManager cameraManager;
    String result;
    String camera;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flashlight);
        aSwitch = findViewById(R.id.switch1);
        textView = findViewById(R.id.OffSwitch);

        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                //Flash Light code
                torch(isChecked);
            }
        });

        }

    private void torch(boolean isChecked) {
        cameraManager = (CameraManager) getSystemService(CAMERA_SERVICE);
        try {
            camera = cameraManager.getCameraIdList()[0];
            cameraManager.setTorchMode(camera,isChecked);
            result = isChecked? "ON":"OFF";
            textView.setText(result);

        } catch (CameraAccessException e) {
            e.printStackTrace();
        }

    }
}

