package com.example.minorproject;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Typeface;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.TextClock;
import android.widget.TextView;

import java.util.Calendar;
import java.util.Locale;

public class clock12 extends AppCompatActivity {

    TextClock textClock;
    TextClock AmPm;
    TextClock date;
    TextView day;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clock12);
        textClock = findViewById(R.id.clockid);
        AmPm = findViewById(R.id.AmPm);
        date = findViewById(R.id.date);
        day = findViewById(R.id.day);

//        fonts
        Typeface clockFont = Typeface.createFromAsset(getApplicationContext().getAssets(), "fonts/Digital_font.otf");
        Typeface weekdayFont = Typeface.createFromAsset(getApplicationContext().getAssets(), "fonts/digital-weekDay.ttf");
        textClock.setTypeface(clockFont);
        AmPm.setTypeface(clockFont);
        date.setTypeface(clockFont);
        day.setTypeface(weekdayFont);


//       day of week
        Calendar weekDay = Calendar.getInstance();
        String dayLongName = (weekDay.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.getDefault()));
        day.setText(dayLongName);


        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
}