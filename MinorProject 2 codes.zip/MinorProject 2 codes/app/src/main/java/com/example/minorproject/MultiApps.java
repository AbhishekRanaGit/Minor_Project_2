package com.example.minorproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Toast;
public class MultiApps extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multi_apps);
    }
    public void clock(View view) {
         boolean hour1 = DateFormat.is24HourFormat(this);
        if (hour1 == true) {
            Intent intent = new Intent(this, clock.class);
            startActivity(intent);
        } else {
            Intent intent1 = new Intent(this, clock12.class);
            startActivity(intent1);
        }
    }
    public void age(View view){
        Intent intent = new Intent(this,AgeFinder.class);
        startActivity(intent);
    }
    public void phncall(View view){
        Intent intent = new Intent(this,phonecall.class);
        startActivity(intent);
    }
    public void flashlight(View view){
        Intent intent = new Intent(this,flashlight.class);
        startActivity(intent);
    }

}
