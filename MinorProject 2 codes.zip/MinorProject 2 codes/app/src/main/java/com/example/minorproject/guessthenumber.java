package com.example.minorproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class guessthenumber extends AppCompatActivity {
    Button btn1;
    Button btn2;
    Button btn3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guessthenumber);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
    }
    public void btn1(View view){
        Intent intent =new Intent(this,Range100.class);
        startActivity(intent);
    }
    public void btn2(View view){
        Intent intent =new Intent(this,Range1000.class);
        startActivity(intent);
    }
    public void btn3(View view){
        Intent intent =new Intent(this,Range10000.class);
        startActivity(intent);
    }
}
