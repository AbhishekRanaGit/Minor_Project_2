package com.example.minorproject;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class Range100 extends AppCompatActivity {
    EditText editInput;
    TextView status;
    int count = 0;
    int lowCount = 0;
    int highCount = 0;
    final int min = 1;
    final int max = 10;
    final int number = new Random().nextInt((max - min) + 1) + min;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_range100);
        editInput = findViewById(R.id.input);
        status = findViewById(R.id.status);
    }
    public void check(View view){

        if (!TextUtils.isEmpty(editInput.getText().toString().trim())) {
            int input = Integer.parseInt(editInput.getText().toString());
            if (input < number) {
                if (lowCount == 1) {
                    status.setText("Again Low");
                    lowCount = 0;
                    count++;
                } else {
                    status.setText("Too Low");
                    lowCount++;
                    count++;
                }
            }
            if (input > number) {
                if (highCount == 1) {
                    status.setText("Again High");
                    highCount = 0;
                    count++;
                } else {
                    status.setText("Too High");
                    highCount++;
                    count++;
                }
            }
            if (input == number) {
                count++;
                status.setText("WON!!!\n You found the number in " + count + " tires.\n Number is " + number + ".");
            }
        }
        else Toast.makeText(this, "You have to guess the number first", Toast.LENGTH_SHORT).show();
    }

}
