package com.example.minorproject;

import android.app.DatePickerDialog;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import org.joda.time.Period;
import org.joda.time.PeriodType;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class AgeFinder extends AppCompatActivity {
    private Button calculate_btn;
    private TextView dob_txt;
    private TextView age_txt;
    String birthday, today;
    DatePickerDialog.OnDateSetListener dateSetListener;

    @RequiresApi(api = Build.VERSION_CODES.O)



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_age_finder);

        TextView today_txt = findViewById(R.id.datetext);
        dob_txt = findViewById(R.id.dobtext);
        age_txt = findViewById(R.id.agetext);
        calculate_btn = findViewById(R.id.calbtn);

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        today = simpleDateFormat.format(Calendar.getInstance().getTime());
        today_txt.setText("Today's date\n" + today);
    }

    public void pick_birthday(View view) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month + 1;
                birthday = dayOfMonth + "/" + month + "/" + year;
                dob_txt.setText("Your Birthday Date\n" + birthday);
            }
        };

        DatePickerDialog datePickerDialog = new DatePickerDialog(view.getContext(), dateSetListener, year, month, day);
        datePickerDialog.getDatePicker().setMaxDate(new Date().getTime());
        datePickerDialog.show();

    }

    public void calculateAge(View view)
    {
        if (birthday == null) {
            Toast.makeText(getApplicationContext(), "please enter your date of birth",
                    Toast.LENGTH_SHORT).show();
        }
        else
        {
            SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("dd/MM/yyyy");
            try {

                Date date1 = simpleDateFormat1.parse(birthday);
                Date date2 = simpleDateFormat1.parse(today);
                long startDate = date1.getTime();
                long enddate = date2.getTime();
                Period period = new Period(startDate,enddate,PeriodType.yearMonthDay());
                int years = period.getYears();
                int months = period.getMonths();
                int days = period.getDays();

                age_txt.setText("Your Age is:\n"+ years + " Year's " + months + " Month's \n" + days + " Day's");

            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
    }

}
