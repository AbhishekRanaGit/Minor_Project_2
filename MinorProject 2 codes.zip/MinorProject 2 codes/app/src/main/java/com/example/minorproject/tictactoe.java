package com.example.minorproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class tictactoe extends AppCompatActivity {
    int count=0;
    EditText player1;
    EditText player2;
    Button playnow;
    public static final String playername1="Playername1";
    public static final String playername2="Playername2";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tictactoe);

        player1=findViewById(R.id.player1);
        player2=findViewById(R.id.player2);
        playnow=findViewById(R.id.play);
    }
    public void play(View view){
        Intent intent =new Intent(this, tictactoegamescreen.class);
        String player1_name =player1.getText().toString();
        if(player1_name.equalsIgnoreCase(""))
        {
            player1.setError("Please enter player name");//it gives user to info message //use any one //
        }
        else
        {
            count++;
        }
        String player2_name=player2.getText().toString();
        if(player2_name.equalsIgnoreCase(""))
        {
            player2.setError("Please enter player name");//it gives user to info message //use any one //
        }
        else
        {
            count++;
        }
        if(count==2){
            intent.putExtra(playername1,player1_name);
            intent.putExtra(playername2,player2_name);
            startActivity(intent);
        }
    }
}
