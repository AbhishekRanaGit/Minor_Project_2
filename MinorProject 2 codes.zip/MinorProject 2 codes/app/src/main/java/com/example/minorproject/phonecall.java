package com.example.minorproject;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class phonecall extends AppCompatActivity {
    private static final int PICK_CONTACT = 0;
    public static final String Extra_NUMBER = "PhoneNumber";
    public static final String Extra_NAME = "personName";

    EditText phnNum, personName;
    Button call;
    Button contact;
    Button save;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phonecall);
        phnNum = findViewById(R.id.phnNum);
        personName = findViewById(R.id.personname);
        call = findViewById(R.id.call);
        save = findViewById(R.id.save);
        contact = findViewById(R.id.contact);

    }

    @Override
    public void onActivityResult(int reqCode, int resultCode, Intent data) {
        super.onActivityResult(reqCode, resultCode, data);

        switch (reqCode) {
            case (PICK_CONTACT):
                if (resultCode == Activity.RESULT_OK) {
                    Uri contactData = data.getData();

                    Cursor cursor = managedQuery(contactData, null, null, null, null);
                    while (cursor.moveToNext()) {
                        String contactId = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));

                        String name = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME));
                        personName.setText(name);


                        String hasPhone = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER));
                        if (hasPhone.equalsIgnoreCase("1"))
                            hasPhone = "true";
                        else
                            hasPhone = "false";

                        if (Boolean.parseBoolean(hasPhone)) {
                            Cursor phones = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = " + contactId, null, null);
                            while (phones.moveToNext()) {
                                String number = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                                phnNum.setText(number);
                            }
                            phones.close();
                        }
                    }
                    cursor.close();
                }
                break;
        }
    }

    //call button
    public void call(View view) {
        String number = phnNum.getText().toString().trim();

        if (ContextCompat.checkSelfPermission(phonecall.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(phonecall.this, new String[]{Manifest.permission.CALL_PHONE}, 1234);
        } else {
            if (number.length() > 0) {
                Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + number));
                startActivity(intent);
            } else
                phnNum.setError("Enter the number first");
        }
    }

    // saving contact button
    public void save(View view) {
        String number = phnNum.getText().toString().trim();
        String name = personName.getText().toString().trim();

        if (ContextCompat.checkSelfPermission(phonecall.this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(phonecall.this, new String[]{Manifest.permission.READ_CONTACTS}, 1234);
        } else {
            if (number.length() > 0) {
                Intent intent = new Intent(this, SaveContact.class);
                intent.putExtra(Extra_NUMBER, number);
                intent.putExtra(Extra_NAME,name);
                startActivity(intent);
            } else {
                Intent intent = new Intent(this, SaveContact.class);
                startActivity(intent);
            }
        }
    }

//contact button

    public void contact(View view) {
        if (ContextCompat.checkSelfPermission(phonecall.this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(phonecall.this, new String[]{Manifest.permission.READ_CONTACTS}, 1234);
        } else {

            Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
            startActivityForResult(intent, PICK_CONTACT);
        }

    }


}
