package com.example.minorproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class tictactoegamescreen extends AppCompatActivity {
    TextView player1name;
    TextView player2name;
    TextView Score1;
    TextView Score2;
    TextView status;
    int score1 = 0;
    int score2 = 0;
    //0 = X
//1 = O
//2 = NULL
    int ActivePlayer = 0;
    int[] GameState = {2, 2, 2, 2, 2, 2, 2, 2, 2};
    int[][] WinPositions = {{0, 1, 2}, {3, 4, 5}, {6, 7, 8},  //row winning
                            {0, 3, 6}, {1, 4, 7}, {2, 5, 8},  //column winning
                             {0, 4, 8}, {2, 4, 6}};         //diagonal winning
    boolean gameActive = true;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tictactoegamescreen);
        player1name = findViewById(R.id.ShowPlayer1);
        player2name = findViewById(R.id.ShowPlayer2);
        Score2 = findViewById(R.id.Score2);
        Score1 = findViewById(R.id.Score1);
        status = findViewById(R.id.status);

        Intent intent = getIntent();
        String playername1 = intent.getStringExtra(tictactoe.playername1);
        String playername2 = intent.getStringExtra(tictactoe.playername2);

        String text1 = playername1.substring(0, 1).toUpperCase() + playername1.substring(1).toLowerCase();
        player1name.setText(text1 + " Score ");
        String text3 = playername2.substring(0, 1).toUpperCase() + playername2.substring(1).toLowerCase();
        player2name.setText(text3 + " Score ");

        status.setText(text1 + "'s Turn - Tap to play");
        Score1.setText(String.valueOf(score1));
        Score2.setText(String.valueOf(score2));

    }

    public void playerTap(View view) {
        Intent intent = getIntent();
        String playername1 = intent.getStringExtra(tictactoe.playername1);
        String playername2 = intent.getStringExtra(tictactoe.playername2);

        ImageView img = (ImageView) view;
        int TappedImg = Integer.parseInt(img.getTag().toString());

        if (!gameActive)
            gameReset(view);

        else {
            if (GameState[TappedImg] == 2) {
                GameState[TappedImg] = ActivePlayer;
                img.setTranslationY(-1000f);
                if (ActivePlayer == 0) {
                    img.setImageResource(R.drawable.x);
                    ActivePlayer = 1;
                    status.setText(playername2 + "'s Turn - Tap to play");

                } else {
                    img.setImageResource(R.drawable.o);
                    ActivePlayer = 0;
                    status.setText(playername1 + "'s Turn - Tap to play");
                }
                img.animate().translationYBy(1000f).setDuration(300);
            }
            //winning position
            for (int[] winPosition : WinPositions) {
                if (GameState[winPosition[0]] == GameState[winPosition[1]] &&
                        GameState[winPosition[1]] == GameState[winPosition[2]] &&
                        GameState[winPosition[0]] != 2) {
                    //winner name
                    gameActive = false;

                    if (GameState[winPosition[0]] == 0) {
                        status.setText(playername1 + " has won ");
                        score1++;
                        Score1.setText(String.valueOf(score1));

                    } else {
                        status.setText(playername2 + " has won");
                        score2++;
                        Score2.setText(String.valueOf(score2));
                    }
                }
                // draw condition
                boolean emptySquare = false;
                for (int squareState : GameState) {
                    if (squareState == 2) {
                        emptySquare = true;
                        break;
                    }
                }
                if (!emptySquare && gameActive) {
                    gameActive = false;
                    status.setText("Match is Draw");
                }
            }
        }
    }

    //Game Reset
    public void gameReset(View view) {
        gameActive = true;
        ActivePlayer = 0;
        for (int i = 0; i < GameState.length; i++)
            GameState[i] = 2;

        ((ImageView) findViewById(R.id.imageView0)).setImageResource(0);
        ((ImageView) findViewById(R.id.imageView1)).setImageResource(0);
        ((ImageView) findViewById(R.id.imageView2)).setImageResource(0);
        ((ImageView) findViewById(R.id.imageView3)).setImageResource(0);
        ((ImageView) findViewById(R.id.imageView4)).setImageResource(0);
        ((ImageView) findViewById(R.id.imageView5)).setImageResource(0);
        ((ImageView) findViewById(R.id.imageView6)).setImageResource(0);
        ((ImageView) findViewById(R.id.imageView7)).setImageResource(0);
        ((ImageView) findViewById(R.id.imageView8)).setImageResource(0);
        Intent intent = getIntent();
        String playername1 = intent.getStringExtra(tictactoe.playername1);
        status.setText(playername1 + "'s Turn - Tap to play");

    }
}
