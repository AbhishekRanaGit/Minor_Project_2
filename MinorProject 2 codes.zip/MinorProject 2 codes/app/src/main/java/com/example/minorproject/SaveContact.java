package com.example.minorproject;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SaveContact extends AppCompatActivity {
    EditText name;
    EditText number;
    Button AddToContact;
    Button AddToExisting;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_save_contact);
        name = findViewById(R.id.name);
        number = findViewById(R.id.number);
        AddToContact= findViewById(R.id.save);
        AddToExisting= findViewById(R.id.Existing);

        Intent intent = getIntent();
        String phnNumber=intent.getStringExtra(phonecall.Extra_NUMBER);
        String personName=intent.getStringExtra(phonecall.Extra_NAME);
        number.setText(phnNumber);
        name.setText(personName);

    }
    public void existing(View view) {
        if(!number.getText().toString().isEmpty())
        {
            Intent intent = new Intent(Intent.ACTION_INSERT_OR_EDIT);
            intent.setType(ContactsContract.RawContacts.CONTENT_ITEM_TYPE);
            intent.putExtra(ContactsContract.Intents.Insert.NAME,name.getText().toString());
            intent.putExtra(ContactsContract.Intents.Insert.PHONE,number.getText().toString());

            if(intent.resolveActivity(getPackageManager()) != null)
                startActivity(intent);
            else
                Toast.makeText(SaveContact.this, "There is no app that support this action", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(SaveContact.this, "Fill All The Fields", Toast.LENGTH_SHORT).show();
        }

    }
    public void newContact(View view)
    {
        if(!name.getText().toString().isEmpty() && !number.getText().toString().isEmpty())
        {
            Intent intent = new Intent(Intent.ACTION_INSERT);
            intent.setType(ContactsContract.RawContacts.CONTENT_TYPE);
            intent.putExtra(ContactsContract.Intents.Insert.NAME,name.getText().toString());
            intent.putExtra(ContactsContract.Intents.Insert.PHONE,number.getText().toString());

            if(intent.resolveActivity(getPackageManager()) != null)
                startActivity(intent);
            else
                Toast.makeText(SaveContact.this, "There is no app that support this action", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(SaveContact.this, "Fill All The Fields", Toast.LENGTH_SHORT).show();
        }

    }

}